// src/lib/leveling.ts
function xpForLevel(level) {
  if (level <= 1) return 0;
  const n = level - 1;
  return 50 * n * (n + 1);
}
function levelFromXp(xp) {
  let level = 1;
  while (xpForLevel(level + 1) <= xp) level++;
  return level;
}
function levelProgress(xp) {
  const level = levelFromXp(xp);
  const floor = xpForLevel(level);
  const ceiling = xpForLevel(level + 1);
  const into = xp - floor;
  const needed = ceiling - floor;
  return {
    level,
    into,
    needed,
    percent: needed > 0 ? Math.min(100, Math.round(into / needed * 100)) : 100
  };
}
function dayKey(date = /* @__PURE__ */ new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
function previousDayKey(key) {
  const [y, m, d] = key.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  date.setDate(date.getDate() - 1);
  return dayKey(date);
}
function nextStreak(streak, lastActiveDay, today = dayKey()) {
  if (lastActiveDay === today) return Math.max(1, streak);
  if (lastActiveDay && previousDayKey(today) === lastActiveDay) return Math.max(1, streak) + 1;
  return 1;
}
function currentStreak(streak, lastActiveDay, today = dayKey()) {
  if (!lastActiveDay) return 0;
  if (lastActiveDay === today) return streak;
  if (previousDayKey(today) === lastActiveDay) return streak;
  return 0;
}
function scoreSolve(attempts, hintsUsed) {
  const penalty = Math.max(0, attempts - 1) * 10 + hintsUsed * 10;
  return Math.max(50, 100 - penalty);
}
function xpForSolve(xpReward, attempts, hintsUsed) {
  return Math.max(1, Math.round(xpReward * scoreSolve(attempts, hintsUsed) / 100));
}
export {
  currentStreak,
  dayKey,
  levelFromXp,
  levelProgress,
  nextStreak,
  previousDayKey,
  scoreSolve,
  xpForLevel,
  xpForSolve
};
