// src/lib/grading.ts
function canonicalize(value) {
  const onPath = /* @__PURE__ */ new WeakSet();
  const walk = (v) => {
    if (v === void 0) return null;
    if (v === null) return null;
    const t = typeof v;
    if (t === "number") {
      if (Number.isNaN(v)) return "__NaN__";
      if (!Number.isFinite(v)) return v > 0 ? "__Infinity__" : "__-Infinity__";
      return v === 0 ? 0 : v;
    }
    if (t === "bigint") return `${v.toString()}n`;
    if (t === "string" || t === "boolean") return v;
    if (t === "function") return "__function__";
    if (t === "symbol") return String(v);
    if (onPath.has(v)) return "__circular__";
    onPath.add(v);
    try {
      if (Array.isArray(v)) return v.map(walk);
      if (v instanceof Set) return { __set: Array.from(v).map(walk) };
      if (v instanceof Map) {
        return { __map: Array.from(v.entries()).map(([k, val]) => [walk(k), walk(val)]) };
      }
      if (v instanceof Date) return { __date: v.toISOString() };
      if (v instanceof Error) return { __error: v.message };
      const out = {};
      for (const key of Object.keys(v).sort()) out[key] = walk(v[key]);
      return out;
    } finally {
      onPath.delete(v);
    }
  };
  try {
    return JSON.stringify(walk(value));
  } catch {
    return String(value);
  }
}
function toJsonish(raw) {
  const variants = /* @__PURE__ */ new Set();
  const trimmed = raw.trim();
  variants.add(trimmed);
  variants.add(
    trimmed.replace(/\bTrue\b/g, "true").replace(/\bFalse\b/g, "false").replace(/\bNone\b/g, "null")
  );
  if (trimmed.includes("'") && !trimmed.includes('"')) {
    variants.add(trimmed.replace(/'/g, '"'));
  }
  variants.add(trimmed.replace(/,\s*([}\]])/g, "$1"));
  return Array.from(variants);
}
function parseExpected(expected) {
  for (const candidate of toJsonish(expected)) {
    try {
      return { ok: true, value: JSON.parse(candidate) };
    } catch {
    }
  }
  return { ok: false };
}
function looseTextEqual(a, b) {
  const clean = (s) => s.trim().replace(/\s+/g, " ");
  return clean(a) === clean(b);
}
function matchesExpected(actual, expected) {
  const parsed = parseExpected(expected);
  if (parsed.ok) {
    if (canonicalize(actual) === canonicalize(parsed.value)) return true;
    if (typeof actual === "string" && typeof parsed.value === "string") {
      return looseTextEqual(actual, parsed.value);
    }
    return false;
  }
  return typeof actual === "string" && looseTextEqual(actual, expected);
}
function displayValue(value) {
  if (typeof value === "string") return JSON.stringify(value);
  if (value === void 0) return "undefined";
  return canonicalize(value);
}
function formatCall(entryFunction, input) {
  return `${entryFunction}(${input})`;
}
function normalizeBlank(text) {
  return text.trim().replace(/\s+/g, " ");
}
function checkBlank(submitted, answer, alternatives = []) {
  const got = normalizeBlank(submitted);
  if (!got) return false;
  const accepted = [answer, ...alternatives].map(normalizeBlank);
  if (accepted.includes(got)) return true;
  const lower = got.toLowerCase();
  return accepted.some((a) => a.toLowerCase() === lower && !/[^a-z0-9_]/i.test(a));
}
function sameSet(a, b) {
  if (a.length !== b.length) return false;
  const sortedA = [...a].sort((x, y) => x - y);
  const sortedB = [...b].sort((x, y) => x - y);
  return sortedA.every((v, i) => v === sortedB[i]);
}
export {
  canonicalize,
  checkBlank,
  displayValue,
  formatCall,
  matchesExpected,
  normalizeBlank,
  parseExpected,
  sameSet
};
