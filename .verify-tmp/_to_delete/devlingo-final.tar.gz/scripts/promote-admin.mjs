#!/usr/bin/env node
/**
 * Promote an existing account to admin (or demote it back to a regular user),
 * by email, run manually and server-side.
 *
 *   node scripts/promote-admin.mjs someone@example.com
 *   node scripts/promote-admin.mjs someone@example.com --demote
 *
 * This is the manual alternative to ADMIN_BOOTSTRAP_EMAIL/ADMIN_BOOTSTRAP_PASSWORD
 * (see server/index.js's bootstrapAdmin()) for promoting an account that already
 * exists - useful the second time you need an admin, since the bootstrap env
 * vars only ever act once (they no-op once any admin account exists). Nothing
 * about admin access is ever settable from the browser or an API request body;
 * this script and the bootstrap env vars are the only two ways an account
 * becomes an admin, and both require someone with access to the server itself.
 */
import * as store from '../server/db.js';

async function main() {
  const [email, ...rest] = process.argv.slice(2);
  const demote = rest.includes('--demote');

  if (!email) {
    console.error('Usage: node scripts/promote-admin.mjs <email> [--demote]');
    process.exitCode = 1;
    return;
  }

  await store.load();
  const user = store.findUserByEmail(email);
  if (!user) {
    console.error(`No account found for ${email}. They need to sign up first.`);
    process.exitCode = 1;
    return;
  }

  if (demote) {
    if (user.role === 'admin' && store.countAdmins() <= 1) {
      console.error(`${email} is the last admin account - promote another account first.`);
      process.exitCode = 1;
      return;
    }
    store.updateUser(user.id, { role: 'user' });
    await store.persistNow();
    console.log(`${email} is now a regular user.`);
    return;
  }

  if (user.role === 'admin') {
    console.log(`${email} is already an admin.`);
    return;
  }

  store.updateUser(user.id, { role: 'admin' });
  await store.persistNow();
  console.log(`${email} is now an admin. They may need to sign out and back in to see admin features.`);
}

main().catch((err) => {
  console.error('Failed to update the account:', err);
  process.exitCode = 1;
});
