import React from 'react';
import { PageHeader } from '../components/ui/PageHeader';
import { SkillRoadmap } from '../components/layout/SkillRoadmap';
import { useGame } from '../context/GameContext';

export const RoadmapPage: React.FC = () => {
  const { stages, stats } = useGame();
  const cleared = stages.filter((s) => s.state === 'Completed').length;

  return (
    <div className="p-6 sm:p-8 max-w-4xl mx-auto">
      <PageHeader
        eyebrow="Your learning journey"
        title="The path to shipping software"
        description="Ten stages, front to back. Clear a stage's lessons, pass its test, and the next one unlocks - click any open node to jump back in."
        aside={
          <div className="text-right">
            <div className="text-3xl font-bold font-mono text-gray-900 dark:text-white">
              {cleared}
              <span className="text-gray-400 text-xl"> / {stages.length}</span>
            </div>
            <div className="text-xs text-gray-500">stages cleared · {stats.xp} XP</div>
          </div>
        }
      />
      <SkillRoadmap />
    </div>
  );
};
