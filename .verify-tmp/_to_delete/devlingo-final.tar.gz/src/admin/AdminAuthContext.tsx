import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { AdminApiError, AdminIdentity, adminApi, getAdminToken } from './adminApi';

interface AdminAuthState {
  admin: AdminIdentity | null;
  /** True while the initial token check (or a login attempt) is in flight. */
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AdminAuthContext = createContext<AdminAuthState | undefined>(undefined);

/**
 * Holds the admin session. On mount, if a token is already saved, it is
 * re-validated against `/api/admin/me` - a stored token from a since-demoted
 * or since-deleted account is never trusted, only what the server says about
 * it right now.
 */
export const AdminAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [admin, setAdmin] = useState<AdminIdentity | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!getAdminToken()) {
        setLoading(false);
        return;
      }
      try {
        const res = await adminApi.me();
        if (!cancelled) setAdmin(res.admin);
      } catch {
        adminApi.logout();
        if (!cancelled) setAdmin(null);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const identity = await adminApi.login(email, password);
    setAdmin(identity);
  }, []);

  const logout = useCallback(() => {
    adminApi.logout();
    setAdmin(null);
  }, []);

  return <AdminAuthContext.Provider value={{ admin, loading, login, logout }}>{children}</AdminAuthContext.Provider>;
};

export function useAdminAuth(): AdminAuthState {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used within AdminAuthProvider');
  return ctx;
}

export { AdminApiError };
