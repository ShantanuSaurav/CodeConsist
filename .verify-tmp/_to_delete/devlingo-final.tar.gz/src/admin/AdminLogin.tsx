import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { AdminApiError, useAdminAuth } from './AdminAuthContext';
import { Button, TextField } from './components/ui';

/**
 * /admin/login. Deliberately a plain email+password form against the SAME
 * accounts as the learner app (there is only one user table) - what makes an
 * account an admin is the server-side `role` field, never anything typed
 * here. A non-admin account that signs in correctly still gets bounced with
 * "This account does not have admin access." (see adminApi.login), so a
 * regular learner account can never wander into the admin shell.
 */
export const AdminLogin: React.FC = () => {
  const { admin, loading, login } = useAdminAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (!loading && admin) return <Navigate to="/admin" replace />;

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login(email, password);
    } catch (err) {
      setError(err instanceof AdminApiError ? err.message : 'Sign in failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-[#0d1117] px-4">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-2 mb-6 justify-center">
          <span className="text-[var(--color-primary)] font-mono text-2xl">&lt;/&gt;</span>
          <span className="text-2xl font-bold text-gray-900 dark:text-white">Devlingo</span>
        </div>
        <div className="bg-white dark:bg-[#161b22] border border-black/5 dark:border-white/5 rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-2 mb-5">
            <ShieldCheck size={20} className="text-[var(--color-primary)]" />
            <h1 className="text-lg font-semibold text-gray-900 dark:text-white">Admin sign in</h1>
          </div>
          <form onSubmit={onSubmit}>
            <TextField label="Email" value={email} onChange={setEmail} placeholder="admin@example.com" />
            <label className="block mb-4">
              <span className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Password</span>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-gray-50 dark:bg-[#0d1117] border border-black/10 dark:border-white/10 text-gray-900 dark:text-gray-100 text-sm focus:outline-none focus:border-[var(--color-primary)]"
              />
            </label>
            {error && (
              <p className="text-sm text-red-500 mb-4" role="alert">
                {error}
              </p>
            )}
            <Button type="submit" variant="primary" className="w-full" disabled={submitting}>
              {submitting ? 'Signing in…' : 'Sign in'}
            </Button>
          </form>
        </div>
        <p className="text-center text-xs text-gray-500 dark:text-gray-500 mt-4">
          This is a separate, backend-enforced sign-in - a learner account never gets in here.
        </p>
      </div>
    </div>
  );
};
